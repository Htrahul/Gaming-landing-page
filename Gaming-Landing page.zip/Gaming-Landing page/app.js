
 function ok(){
  let onC=document.querySelector('.Hamburger')
  let nav=document.querySelector('.nav')
  let ulI=document.querySelector('.shut')

  onC.addEventListener('click',function () {
    nav.style.right='0%'
    onC.style.display='none'
  })
  ulI.addEventListener('click',function () {
    nav.style.right='-60%'
    onC.style.display='block'
  })
  
 }
ok()